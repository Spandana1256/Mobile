package com.cg.mra.exception;

public class AccountException extends Exception{
	public AccountException(String msg) {
		super(msg);
	}
	

}
