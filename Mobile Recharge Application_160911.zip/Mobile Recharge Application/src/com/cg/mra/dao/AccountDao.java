package com.cg.mra.dao;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountException;

public interface AccountDao {
	 Account getAccountDetails(String mobileNo);
	    double rechargeAccount(String mobileno, double rechargeAmount);
		Account getAccount(String mobile);
}
